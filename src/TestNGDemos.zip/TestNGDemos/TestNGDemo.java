package TestNGDemos;

import org.testng.annotations.Test;

public class TestNGDemo {


    @Test
    public void mytestmethod()
    {

        System.out.println("mytestmethod()");

    }

    @Test
    public void myAnotheMethod()
    {

        System.out.println("myAnotheMethod()");

    }


    @Test
    public void justAMethod()
    {

        System.out.println("justAMethod()");

    }



}
